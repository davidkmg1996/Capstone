from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from google.cloud import storage
import tensorflow as tf
from PIL import Image
import numpy as np
import io
import os
import json
import psycopg2
from werkzeug.security import check_password_hash
from ESTest import MultiSymptom, load_json, symptomatic

# -------------------------
# --- FLASK APP SETUP ---
# -------------------------
app = Flask(__name__, static_folder='build', static_url_path='/')

MODEL_BUCKET = "modelplantb"
MODEL_FILE = "plant_disease_model_sequence.h5"

# Environment variables
CLOUD_SQL_CONNECTION_NAME = os.environ.get('CLOUD_SQL_CONNECTION_NAME')
DB_USER = os.environ.get('DB_USER')
DB_PASSWORD = os.environ.get('DB_PASSWORD')
DB_NAME = os.environ.get('DB_NAME')

# Allowed origins for CORS
ALLOWED_ORIGINS = [
    "http://localhost:8081",
    "https://plantdisease-932821527783.europe-west1.run.app"
]

# Initialize CORS for all /api/* endpoints
CORS(app, resources={r"/api/*": {"origins": ALLOWED_ORIGINS}}, supports_credentials=True)

# -------------------------
# --- HELPER FUNCTIONS ---
# -------------------------
def psycopg_connect():
    """Connect to PostgreSQL DB via Cloud SQL."""
    host_path = f"/cloudsql/{CLOUD_SQL_CONNECTION_NAME}"
    try:
        conn = psycopg2.connect(
            user=DB_USER,
            password=DB_PASSWORD,
            dbname=DB_NAME,
            host=host_path,
            connect_timeout=5
        )
        return conn
    except Exception as e:
        print(f"[ERROR] DB connection failed: {e}")
        return None

def load_model_from_gcs(bucket_name, file_name):
    try:
        client = storage.Client()
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(file_name)
        model_bytes = blob.download_as_bytes()
        model = tf.keras.models.load_model(io.BytesIO(model_bytes), compile=False)
        print("[INFO] Model loaded successfully")
        return model
    except Exception as e:
        print(f"[ERROR] Failed to load model from GCS: {e}")
        return None

def preprocess_image(file, target_size=(224, 224)):
    img = Image.open(file).convert("RGB")
    img = img.resize(target_size)
    img_array = np.array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array

# -------------------------
# --- LOAD MODEL ---
# -------------------------
model = load_model_from_gcs(MODEL_BUCKET, MODEL_FILE)
if model is None:
    print("[WARNING] Model is None, /api/diagnoseImage will fail until model is loaded")

# -------------------------
# --- API ENDPOINTS ---
# -------------------------
@app.route("/api/login", methods=["POST"])
def login():
    data = request.json or {}
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "Username and password required"}), 400

    conn = psycopg_connect()
    if not conn:
        return jsonify({"error": "Failed to connect to DB"}), 500

    try:
        cur = conn.cursor()
        cur.execute("SELECT password_hash FROM users WHERE username = %s", (username,))
        user = cur.fetchone()
        cur.close()
        conn.close()

        if not user:
            return jsonify({"error": "User not found"}), 404

        password_hash = user[0]
        if check_password_hash(password_hash, password):
            return jsonify({"message": "Login successful"}), 200
        else:
            return jsonify({"error": "Invalid password"}), 401
    except Exception as e:
        conn.close()
        return jsonify({"error": str(e)}), 500

@app.route("/api/diagnose", methods=["POST"])
def diagnose():
    input_data = request.get_json()
    if not input_data:
        return jsonify({"error": "No input provided"}), 400

    plant_name = input_data.get("plant")
    symptom_list = input_data.get("symptoms", [])

    kb_data = load_json("KB.json")
    engine = MultiSymptom(kb_data)
    engine.reset()
    engine.declare(symptomatic(name=plant_name, symptoms=symptom_list))
    engine.run()

    prob_list = engine.results.get("Probability", [])
    formatted_prob = "\n".join([f"{d} {p}%" for d, p in prob_list])

    response_text = f"Plant: {plant_name}\nProbability:\n{formatted_prob}"
    return response_text

@app.route("/api/diagnoseImage", methods=["POST"])
def diagnose_image():
    if model is None:
        return jsonify({"error": "Model not loaded"}), 500

    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    file = request.files["image"]
    img_array = preprocess_image(file)
    disease_pred, symptom_pred = model.predict(img_array)
    predicted_class_index = int(np.argmax(disease_pred))
    predicted_confidence = float(np.max(disease_pred) * 100)

    return jsonify({
        "predicted_class_index": predicted_class_index,
        "confidence_percent": predicted_confidence
    })

# -------------------------
# --- STATIC / FRONTEND ---
# -------------------------
@app.route('/')
def serve_index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    if os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    return send_from_directory(app.static_folder, 'index.html')

# -------------------------
# --- RUN SERVER ---
# -------------------------
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    print(f"[INFO] Starting Flask app on port {port}")
    app.run(host="0.0.0.0", port=port)
